﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace App3.Services
{
    public interface IMediaService
    {
       // SQLiteConnection SQLiteConnection();
        //Task<bool> CheckNewworkConnectivity();
       // string ViewMediaInPdf(byte[] fileStream, string fileName);
       // byte[] GetMediaInBytes(string filePath);
       // string ViewMediaInPNG(byte[] fileStream, string fileName);
       // byte[] ResizeImage(byte[] imageStream, float width, float height);
       // Task<string> SaveFileToDisk(Stream stream, string fileName);
    }
}
