﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App3.Managers.SettingsManager
{
    public interface ISettingsManager
    {
        string ApiHost { get; }
    }
}
