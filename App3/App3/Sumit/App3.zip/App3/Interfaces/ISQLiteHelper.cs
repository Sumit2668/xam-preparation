﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App3.Interfaces
{
    public interface ISQLiteHelper
    {
        string GetLocalFilePath(string filename);
    }
}
