﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace NewDesignTestApp.AnimationTrigger
{
    public class ExpandButtonTriggerAction : TriggerAction<ImageButton>
    {
        protected async override void Invoke(ImageButton button)
        {
            await button.ScaleTo(0.95, 50, Easing.CubicOut);
            await button.ScaleTo(1, 50, Easing.CubicIn);
        }
    }
}
